/* admin_dashboard.php — Part 1
   Original lines 1-320
   Paste this part immediately after Part 0.
*/

<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include "connection.php";

/*
|--------------------------------------------------------------------------
| Check login
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];

/*
|--------------------------------------------------------------------------
| Check that the current user is an admin
|--------------------------------------------------------------------------
*/

$user_stmt = $conn->prepare("
    SELECT
        id,
        first_name,
        last_name,
        email,
        user_type
    FROM users
    WHERE id = ?
    LIMIT 1
");

if (!$user_stmt) {
    die("SQL ERROR: " . $conn->error);
}

$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();

$user_result = $user_stmt->get_result();
$current_user = $user_result->fetch_assoc();

$user_stmt->close();

if (!$current_user) {
    session_destroy();
    header("Location: login.php");
    exit();
}

$_SESSION['user_type'] = $current_user['user_type'];

if ($current_user['user_type'] !== 'admin') {
    header("Location: dashboard.php");
    exit();
}

/*
|--------------------------------------------------------------------------
| Helper function for count queries
|--------------------------------------------------------------------------
*/

function getCount(mysqli $conn, string $query): int
{
    $result = $conn->query($query);

    if (!$result) {
        return 0;
    }

    $row = $result->fetch_assoc();

    return (int)($row['total'] ?? 0);
}

/*
|--------------------------------------------------------------------------
| Dashboard statistics
|--------------------------------------------------------------------------
*/

$total_users = getCount(
    $conn,
    "SELECT COUNT(*) AS total FROM users"
);

$total_customers = getCount(
    $conn,
    "SELECT COUNT(*) AS total
     FROM users
     WHERE user_type = 'customer'"
);

$total_owners = getCount(
    $conn,
    "SELECT COUNT(*) AS total
     FROM users
     WHERE user_type = 'owner'"
);

$total_attraction_owners = getCount(
    $conn,
    "SELECT COUNT(*) AS total
     FROM users
     WHERE user_type = 'attraction_owner'"
);

$pending_requests = getCount(
    $conn,
    "SELECT COUNT(*) AS total
     FROM role_requests
     WHERE request_status = 'pending'"
);

$approved_requests = getCount(
    $conn,
    "SELECT COUNT(*) AS total
     FROM role_requests
     WHERE request_status = 'approved'"
);

$rejected_requests = getCount(
    $conn,
    "SELECT COUNT(*) AS total
     FROM role_requests
     WHERE request_status = 'rejected'"
);

$total_cabins = getCount(
    $conn,
    "SELECT COUNT(*) AS total FROM cabins"
);

$total_bookings = getCount(
    $conn,
    "SELECT COUNT(*) AS total FROM bookings"
);

$confirmed_bookings = getCount(
    $conn,
    "SELECT COUNT(*) AS total
     FROM bookings
     WHERE status = 'confirmed'"
);

$pending_bookings = getCount(
    $conn,
    "SELECT COUNT(*) AS total
     FROM bookings
     WHERE status = 'pending'"
);

$total_attractions = getCount(
    $conn,
    "SELECT COUNT(*) AS total FROM attractions"
);



/*
|--------------------------------------------------------------------------
| Admin revenue statistics - current year only
|--------------------------------------------------------------------------
|
| Admin revenue comes from three sources:
| 1. 10% commission from completed bookings.
| 2. Paid and approved cabin-owner registrations.
| 3. Paid and approved attraction-owner registrations.
|
*/

$current_year = (int)date('Y');

/* Booking commissions for the current year */
$booking_revenue_result = $conn->query("\n    SELECT\n        COALESCE(SUM(admin_commission), 0) AS total,\n        COUNT(*) AS completed_bookings\n    FROM bookings\n    WHERE status = 'confirmed'\n      AND end_date <= CURDATE()\n      AND YEAR(end_date) = YEAR(CURDATE())\n");

$booking_revenue_row = $booking_revenue_result
    ? $booking_revenue_result->fetch_assoc()
    : [];

$booking_commission_revenue = (float)($booking_revenue_row['total'] ?? 0);
$completed_revenue_bookings = (int)($booking_revenue_row['completed_bookings'] ?? 0);

/* Cabin-owner registration revenue for the current year */
$cabin_registration_result = $conn->query("\n    SELECT\n        COALESCE(SUM(payment_amount), 0) AS total,\n        COUNT(*) AS registrations\n    FROM role_requests\n    WHERE requested_role = 'owner'\n      AND request_status = 'approved'\n      AND LOWER(payment_status) = 'paid'\n      AND YEAR(created_at) = YEAR(CURDATE())\n");

$cabin_registration_row = $cabin_registration_result
    ? $cabin_registration_result->fetch_assoc()
    : [];

$cabin_owner_registration_revenue = (float)($cabin_registration_row['total'] ?? 0);
$cabin_owner_registrations = (int)($cabin_registration_row['registrations'] ?? 0);

/* Attraction-owner registration revenue for the current year */
$attraction_registration_result = $conn->query("\n    SELECT\n        COALESCE(SUM(payment_amount), 0) AS total,\n        COUNT(*) AS registrations\n    FROM role_requests\n    WHERE requested_role = 'attraction_owner'\n      AND request_status = 'approved'\n      AND LOWER(payment_status) = 'paid'\n      AND YEAR(created_at) = YEAR(CURDATE())\n");

$attraction_registration_row = $attraction_registration_result
    ? $attraction_registration_result->fetch_assoc()
    : [];

$attraction_owner_registration_revenue = (float)($attraction_registration_row['total'] ?? 0);
$attraction_owner_registrations = (int)($attraction_registration_row['registrations'] ?? 0);

/* Total admin revenue for the current year */
$total_admin_revenue =
    $booking_commission_revenue +
    $cabin_owner_registration_revenue +
    $attraction_owner_registration_revenue;

/* Total admin revenue for the current month */
$booking_month_result = $conn->query("\n    SELECT COALESCE(SUM(admin_commission), 0) AS total\n    FROM bookings\n    WHERE status = 'confirmed'\n      AND end_date <= CURDATE()\n      AND YEAR(end_date) = YEAR(CURDATE())\n      AND MONTH(end_date) = MONTH(CURDATE())\n");

$booking_revenue_month = $booking_month_result
    ? (float)($booking_month_result->fetch_assoc()['total'] ?? 0)
    : 0;

$cabin_month_result = $conn->query("\n    SELECT COALESCE(SUM(payment_amount), 0) AS total\n    FROM role_requests\n    WHERE requested_role = 'owner'\n      AND request_status = 'approved'\n      AND LOWER(payment_status) = 'paid'\n      AND YEAR(created_at) = YEAR(CURDATE())\n      AND MONTH(created_at) = MONTH(CURDATE())\n");

$cabin_registration_revenue_month = $cabin_month_result
    ? (float)($cabin_month_result->fetch_assoc()['total'] ?? 0)
    : 0;

$attraction_month_result = $conn->query("\n    SELECT COALESCE(SUM(payment_amount), 0) AS total\n    FROM role_requests\n    WHERE requested_role = 'attraction_owner'\n      AND request_status = 'approved'\n      AND LOWER(payment_status) = 'paid'\n      AND YEAR(created_at) = YEAR(CURDATE())\n      AND MONTH(created_at) = MONTH(CURDATE())\n");

$attraction_registration_revenue_month = $attraction_month_result
    ? (float)($attraction_month_result->fetch_assoc()['total'] ?? 0)
    : 0;

$total_admin_revenue_month =
    $booking_revenue_month +
    $cabin_registration_revenue_month +
    $attraction_registration_revenue_month;

/* Revenue-source chart */
$revenue_source_labels = [
    'Booking Commissions',
    'Cabin Owner Registrations',
    'Attraction Owner Registrations'
];

$revenue_source_values = [
    $booking_commission_revenue,
    $cabin_owner_registration_revenue,
    $attraction_owner_registration_revenue
];

/* Monthly revenue by source - January to December */
$month_labels = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];

$monthly_booking_commissions = array_fill(0, 12, 0.0);
$monthly_cabin_registrations = array_fill(0, 12, 0.0);
$monthly_attraction_registrations = array_fill(0, 12, 0.0);

$monthly_booking_result = $conn->query("\n    SELECT\n        MONTH(end_date) AS month_number,\n        COALESCE(SUM(admin_commission), 0) AS total\n    FROM bookings\n    WHERE status = 'confirmed'\n      AND end_date <= CURDATE()\n      AND YEAR(end_date) = YEAR(CURDATE())\n    GROUP BY MONTH(end_date)\n");

if ($monthly_booking_result) {
    while ($row = $monthly_booking_result->fetch_assoc()) {
        $month_index = (int)$row['month_number'] - 1;

        if ($month_index >= 0 && $month_index < 12) {
            $monthly_booking_commissions[$month_index] = (float)$row['total'];
        }
    }
}

$monthly_registration_result = $conn->query("\n    SELECT\n        MONTH(created_at) AS month_number,\n        requested_role,\n        COALESCE(SUM(payment_amount), 0) AS total\n    FROM role_requests\n    WHERE request_status = 'approved'\n      AND LOWER(payment_status) = 'paid'\n      AND requested_role IN ('owner', 'attraction_owner')\n      AND YEAR(created_at) = YEAR(CURDATE())\n    GROUP BY MONTH(created_at), requested_role\n");

if ($monthly_registration_result) {
    while ($row = $monthly_registration_result->fetch_assoc()) {
        $month_index = (int)$row['month_number'] - 1;

        if ($month_index < 0 || $month_index >= 12) {
            continue;
        }

        if ($row['requested_role'] === 'owner') {
            $monthly_cabin_registrations[$month_index] = (float)$row['total'];
        } elseif ($row['requested_role'] === 'attraction_owner') {
            $monthly_attraction_registrations[$month_index] = (float)$row['total'];
        }
    }
}

/* Top cabin owners by the commission they generated for the admin */
$top_owners = $conn->query("\n    SELECT\n        u.id,\n        u.first_name,\n        u.last_name,\n        COUNT(DISTINCT c.id) AS cabins_count,\n        COUNT(b.id) AS bookings_count,\n        COALESCE(SUM(b.admin_commission), 0) AS admin_commission\n    FROM users u\n    LEFT JOIN cabins c\n        ON c.owner_id = u.id\n    LEFT JOIN bookings b\n        ON b.cabin_id = c.id\n       AND b.status = 'confirmed'\n       AND b.end_date <= CURDATE()\n       AND YEAR(b.end_date) = YEAR(CURDATE())\n    WHERE u.user_type = 'owner'\n    GROUP BY u.id, u.first_name, u.last_name\n    ORDER BY admin_commission DESC, bookings_count DESC\n    LIMIT 5\n");

/* Top cabins by the commission they generated for the admin */
$top_cabins = $conn->query("\n    SELECT\n        c.id,\n        c.name,\n        u.first_name,\n        u.last_name,\n        COUNT(b.id) AS bookings_count,\n        COALESCE(SUM(b.admin_commission), 0) AS admin_commission\n    FROM cabins c\n    INNER JOIN users u\n        ON u.id = c.owner_id\n    LEFT JOIN bookings b\n        ON b.cabin_id = c.id\n       AND b.status = 'confirmed'\n       AND b.end_date <= CURDATE()\n       AND YEAR(b.end_date) = YEAR(CURDATE())\n    GROUP BY c.id, c.name, u.first_name, u.last_name\n    ORDER BY admin_commission DESC, bookings_count DESC\n    LIMIT 5\n");


/*
|--------------------------------------------------------------------------
| Recent partner requests
|--------------------------------------------------------------------------
*/

$recent_requests = $conn->query("
    SELECT
        rr.id,
        rr.requested_role,
        rr.business_name,
        rr.payment_amount,
        rr.payment_status,
        rr.request_status,
        rr.created_at,
        u.first_name,
        u.last_name,
        u.email
    FROM role_requests rr

    /* admin_dashboard.php — Part 2
   Original lines 321-640
   Paste this part immediately after Part 1.
*/

    INNER JOIN users u
        ON rr.user_id = u.id
    ORDER BY rr.id DESC
    LIMIT 5
");

/*
|--------------------------------------------------------------------------
| Recent users
|--------------------------------------------------------------------------
*/

$recent_users = $conn->query("
    SELECT
        id,
        first_name,
        last_name,
        email,
        user_type
    FROM users
    ORDER BY id DESC
    LIMIT 5
");

function formatRole(string $role): string
{
    $roles = [
        'admin' => 'Administrator',
        'customer' => 'Customer',
        'owner' => 'Cabin Owner',
        'attraction_owner' => 'Attraction Owner'
    ];

    return $roles[$role] ?? ucfirst(str_replace('_', ' ', $role));
}

function formatRequestRole(string $role): string
{
    return $role === 'owner'
        ? 'Cabin Owner'
        : 'Attraction Owner';
}

function formatStatus(string $status): string
{
    return ucfirst(str_replace('_', ' ', $status));
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Admin Dashboard | ZimmerSmart</title>

    <link
        rel="stylesheet"
        href="style.css?v=<?= time() ?>"
    >

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        .admin-financial-section { margin-top: 34px; }
        .admin-financial-heading { margin-bottom: 18px; }
        .admin-financial-heading span { font-weight: 700; opacity: .7; }
        .admin-financial-heading h2 { margin: 5px 0; }
        .admin-financial-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 18px; }
        .admin-financial-card, .admin-financial-panel { background: #fff; border-radius: 18px; padding: 22px; box-shadow: 0 10px 30px rgba(0,0,0,.07); }
        .admin-financial-card span { display: block; font-weight: 700; opacity: .7; }
        .admin-financial-card strong { display: block; margin: 10px 0 4px; font-size: 1.7rem; }
        .admin-financial-card small { opacity: .65; }
        .admin-financial-layout { display: grid; grid-template-columns: minmax(0, 1.45fr) minmax(280px, .55fr); gap: 20px; margin-top: 22px; }
        .admin-financial-panel h3 { margin-top: 0; }
        .admin-chart-description { margin-top: -4px; opacity: .68; }
        .admin-table-wrap { overflow-x: auto; }
        .admin-financial-table { width: 100%; border-collapse: collapse; }
        .admin-financial-table th, .admin-financial-table td { padding: 12px 10px; border-bottom: 1px solid rgba(0,0,0,.08); text-align: left; white-space: nowrap; }
        .admin-financial-table th { font-size: .85rem; opacity: .7; }
        .admin-financial-table td strong { display: block; }
        .admin-rank { width: 34px; height: 34px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; background: rgba(120,80,220,.12); font-weight: 800; }
        .admin-financial-tables { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 22px; }
        @media (max-width: 950px) { .admin-financial-layout, .admin-financial-tables { grid-template-columns: 1fr; } }
    </style>
</head>

<body>

<?php include "navbar.php"; ?>

<main class="admin-dashboard-page">

    <section class="admin-dashboard-header">

        <div>

            <span class="admin-dashboard-label">
                ZimmerSmart Administration
            </span>

            <h1>
                Welcome,
                <?= htmlspecialchars($current_user['first_name']) ?>
            </h1>

            <p>
                Manage users, partner requests, cabins, attractions
                and bookings from one dashboard.
            </p>

        </div>

        <div class="admin-profile-summary">

            <div class="admin-profile-avatar">

                <?= htmlspecialchars(
                    strtoupper(
                        mb_substr($current_user['first_name'], 0, 1) .
                        mb_substr($current_user['last_name'], 0, 1)
                    )
                ) ?>

            </div>

            <div>

                <strong>
                    <?= htmlspecialchars(
                        $current_user['first_name'] . ' ' .
                        $current_user['last_name']
                    ) ?>
                </strong>

                <span>
                    <?= htmlspecialchars($current_user['email']) ?>
                </span>

                <small>Administrator</small>

            </div>

        </div>

    </section>

    <?php if ($pending_requests > 0): ?>

        <section class="admin-dashboard-notice">

            <div class="admin-notice-icon">
                🔔
            </div>

            <div>

                <strong>
                    You have <?= $pending_requests ?> partner
                    <?= $pending_requests === 1 ? 'request' : 'requests' ?>
                    waiting for review.
                </strong>

                <p>
                    Review the requests and approve or reject them.
                </p>

            </div>

            <a href="admin_role_requests.php">
                Review requests
            </a>

        </section>

    <?php endif; ?>

    <section class="admin-stats-grid">

        <article class="admin-stat-card">

            <div class="admin-stat-icon">
                👥
            </div>

            <div>

                <span>Total Users</span>

                <strong>
                    <?= number_format($total_users) ?>
                </strong>

                <small>
                    <?= number_format($total_customers) ?> customers
                </small>

            </div>

        </article>

        <article class="admin-stat-card">

            <div class="admin-stat-icon">
                ⏳
            </div>

            <div>

                <span>Pending Requests</span>

                <strong>
                    <?= number_format($pending_requests) ?>
                </strong>

                <small>
                    Waiting for administrator review
                </small>

            </div>

        </article>

        <article class="admin-stat-card">

            <div class="admin-stat-icon">
                🏡
            </div>

            <div>

                <span>Cabin Owners</span>

                <strong>
                    <?= number_format($total_owners) ?>
                </strong>

                <small>
                    <?= number_format($total_cabins) ?> cabins
                </small>

            </div>

        </article>

        <article class="admin-stat-card">

            <div class="admin-stat-icon">
                🎡
            </div>

            <div>

                <span>Attraction Owners</span>

                <strong>
                    <?= number_format($total_attraction_owners) ?>
                </strong>

                <small>
                    <?= number_format($total_attractions) ?> attractions
                </small>

            </div>

        </article>

        <article class="admin-stat-card">

            <div class="admin-stat-icon">
                📅
            </div>

            <div>

                <span>Total Bookings</span>

                <strong>
                    <?= number_format($total_bookings) ?>
                </strong>

                <small>
                    <?= number_format($confirmed_bookings) ?> confirmed
                </small>

            </div>

        </article>

        <article class="admin-stat-card">

            <div class="admin-stat-icon">
                ✅
            </div>

            <div>

                <span>Approved Requests</span>

                <strong>
                    <?= number_format($approved_requests) ?>
                </strong>

                <small>
                    <?= number_format($rejected_requests) ?> rejected
                </small>

            </div>

        </article>

    </section>

    /* admin_dashboard.php — Part 3
   Original lines 641-960
   Paste this part immediately after Part 2.
*/




    <section class="admin-financial-section">

        <div class="admin-financial-heading">
            <span>Admin income</span>
            <h2>My Revenue Overview — <?= $current_year ?></h2>
            <p>
                Your income for the current year, divided by its source.
            </p>
        </div>

        <div class="admin-financial-grid">

            <article class="admin-financial-card">
                <span>💰 Total Admin Revenue</span>
                <strong>₪<?= number_format($total_admin_revenue, 2) ?></strong>
                <small>All three revenue sources in <?= $current_year ?></small>
            </article>

            <article class="admin-financial-card">
                <span>📆 Revenue This Month</span>
                <strong>₪<?= number_format($total_admin_revenue_month, 2) ?></strong>
                <small>Revenue from all sources this month</small>
            </article>

            <article class="admin-financial-card">
                <span>📅 Booking Commissions</span>
                <strong>₪<?= number_format($booking_commission_revenue, 2) ?></strong>
                <small>10% from <?= number_format($completed_revenue_bookings) ?> completed bookings</small>
            </article>

            <article class="admin-financial-card">
                <span>🏡 Cabin Owner Registrations</span>
                <strong>₪<?= number_format($cabin_owner_registration_revenue, 2) ?></strong>
                <small><?= number_format($cabin_owner_registrations) ?> paid and approved registrations</small>
            </article>

            <article class="admin-financial-card">
                <span>🎡 Attraction Owner Registrations</span>
                <strong>₪<?= number_format($attraction_owner_registration_revenue, 2) ?></strong>
                <small><?= number_format($attraction_owner_registrations) ?> paid and approved registrations</small>
            </article>

        </div>

        <div class="admin-financial-layout">

            <div class="admin-financial-panel">
                <h3>Monthly Revenue by Source — <?= $current_year ?></h3>
                <p class="admin-chart-description">
                    See how much each source contributed in every month.
                </p>
                <canvas id="adminMonthlyRevenueChart"></canvas>
            </div>

            <div class="admin-financial-panel">
                <h3>Where My Revenue Comes From</h3>
                <p class="admin-chart-description">
                    Distribution of your total income in <?= $current_year ?>.
                </p>
                <canvas id="adminRevenueSourcesChart"></canvas>
            </div>

        </div>

        <div class="admin-financial-tables">

            <div class="admin-financial-panel">
                <h3>Top Cabin Owners — <?= $current_year ?></h3>

                <div class="admin-table-wrap">
                    <table class="admin-financial-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Owner</th>
                                <th>Cabins</th>
                                <th>Completed Bookings</th>
                                <th>Your Commission</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($top_owners && $top_owners->num_rows > 0): ?>
                            <?php $owner_rank = 1; ?>
                            <?php while ($owner = $top_owners->fetch_assoc()): ?>
                                <tr>
                                    <td><span class="admin-rank"><?= $owner_rank++ ?></span></td>
                                    <td><strong><?= htmlspecialchars($owner['first_name'] . ' ' . $owner['last_name']) ?></strong></td>
                                    <td><?= number_format((int)$owner['cabins_count']) ?></td>
                                    <td><?= number_format((int)$owner['bookings_count']) ?></td>
                                    <td>₪<?= number_format((float)$owner['admin_commission'], 2) ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="5">No completed booking statistics for this year.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="admin-financial-panel">
                <h3>Top Cabins — <?= $current_year ?></h3>

                <div class="admin-table-wrap">
                    <table class="admin-financial-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Cabin</th>
                                <th>Owner</th>
                                <th>Completed Bookings</th>
                                <th>Your Commission</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($top_cabins && $top_cabins->num_rows > 0): ?>
                            <?php $cabin_rank = 1; ?>
                            <?php while ($cabin = $top_cabins->fetch_assoc()): ?>
                                <tr>
                                    <td><span class="admin-rank"><?= $cabin_rank++ ?></span></td>
                                    <td><strong><?= htmlspecialchars($cabin['name']) ?></strong></td>
                                    <td><?= htmlspecialchars($cabin['first_name'] . ' ' . $cabin['last_name']) ?></td>
                                    <td><?= number_format((int)$cabin['bookings_count']) ?></td>
                                    <td>₪<?= number_format((float)$cabin['admin_commission'], 2) ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="5">No completed cabin statistics for this year.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

    </section>


    <section class="admin-management-section">

        <div class="admin-section-heading">

            <span>Management</span>

            <h2>Administration Tools</h2>

            <p>
                Choose the section you want to manage.
            </p>

        </div>

        <div class="admin-management-grid">

            <a
                href="admin_role_requests.php"
                class="admin-management-card"
            >

                <div class="admin-management-icon">
                    🤝
                </div>

                <div>

                    <h3>Partner Requests</h3>

                    <p>
                        Approve or reject requests from cabin and
                        attraction owners.
                    </p>

                    <?php if ($pending_requests > 0): ?>

                        <span class="admin-card-badge">
                            <?= $pending_requests ?> pending
                        </span>

                    <?php endif; ?>

                </div>

                <span class="admin-management-arrow">
                    →
                </span>

            </a>

            <a
                href="admin_users.php"
                class="admin-management-card"
            >

                <div class="admin-management-icon">
                    👥
                </div>

                <div>

                    <h3>Manage Users</h3>

                    <p>
                        View all users and manage their account roles
                        and information.
                    </p>

                </div>

                <span class="admin-management-arrow">
                    →
                </span>

            </a>

            <a
                href="managecabins.php"
                class="admin-management-card"
            >

                <div class="admin-management-icon">
                    🏘️
                </div>

                <div>

                    <h3>Manage Cabins</h3>

                    <p>
                        View and manage the cabins available on
                        ZimmerSmart.
                    </p>

                </div>

                <span class="admin-management-arrow">
                    →
                </span>

            </a>




        </div>

    </section>

    <section class="admin-dashboard-columns">

        <div class="admin-dashboard-panel">

            <div class="admin-panel-header">

                <div>

                    <span>Latest activity</span>

                    <h2>Recent Partner Requests</h2>

                </div>

                <a href="admin_role_requests.php">
                    View all
                </a>

            </div>

            <?php if (
                $recent_requests &&
                $recent_requests->num_rows > 0
            ): ?>

                <div class="admin-request-list">

                    <?php while (
                        $request = $recent_requests->fetch_assoc()
                    ): ?>

                        <article class="admin-request-row">

                            <div class="admin-request-icon">

                                <?= $request['requested_role'] === 'owner'
                                    ? '🏡'
                                    : '🎡' ?>

                            </div>

                            <div class="admin-request-main">

                                <div class="admin-request-title">

                                    <div>

                                        <strong>
                                            <?= htmlspecialchars(
                                                $request['business_name']
                                            ) ?>
                                        </strong>

                                        <span>
                                            <?= htmlspecialchars(
                                                $request['first_name'] .
                                                ' ' .
                                                $request['last_name']
                                            ) ?>
                                        </span>

                                    </div>

                                    <span class="admin-status <?= htmlspecialchars(
                                        $request['request_status']
                                    ) ?>">

                                        <?= htmlspecialchars(
                                            formatStatus(

                                            /* admin_dashboard.php — Part 4
   Original lines 961-1236
   Paste this part immediately after Part 3.
*/

                                                $request['request_status']
                                            )
                                        ) ?>

                                    </span>

                                </div>

                                <div class="admin-request-meta">

                                    <span>
                                        <?= htmlspecialchars(
                                            formatRequestRole(
                                                $request['requested_role']
                                            )
                                        ) ?>
                                    </span>

                                    <span>
                                        ₪<?= number_format(
                                            (float)$request['payment_amount'],
                                            2
                                        ) ?>
                                    </span>

                                    <span>
                                        <?= date(
                                            'd/m/Y',
                                            strtotime($request['created_at'])
                                        ) ?>
                                    </span>

                                </div>

                            </div>

                        </article>

                    <?php endwhile; ?>

                </div>

            <?php else: ?>

                <div class="admin-empty-state">

                    <span>📭</span>

                    <h3>No partner requests yet</h3>

                    <p>
                        New requests will appear here.
                    </p>

                </div>

            <?php endif; ?>

        </div>

        <div class="admin-dashboard-panel">

            <div class="admin-panel-header">

                <div>

                    <span>New accounts</span>

                    <h2>Recent Users</h2>

                </div>

                <a href="admin_users.php">
                    View all
                </a>

            </div>

            <?php if (
                $recent_users &&
                $recent_users->num_rows > 0
            ): ?>

                <div class="admin-users-list">

                    <?php while (
                        $recent_user = $recent_users->fetch_assoc()
                    ): ?>

                        <article class="admin-user-row">

                            <div class="admin-user-avatar">

                                <?= htmlspecialchars(
                                    strtoupper(
                                        mb_substr(
                                            $recent_user['first_name'],
                                            0,
                                            1
                                        ) .
                                        mb_substr(
                                            $recent_user['last_name'],
                                            0,
                                            1
                                        )
                                    )
                                ) ?>

                            </div>

                            <div class="admin-user-details">

                                <strong>
                                    <?= htmlspecialchars(
                                        $recent_user['first_name'] .
                                        ' ' .
                                        $recent_user['last_name']
                                    ) ?>
                                </strong>

                                <span>
                                    <?= htmlspecialchars(
                                        $recent_user['email']
                                    ) ?>
                                </span>

                            </div>

                            <span class="admin-user-role <?= htmlspecialchars(
                                $recent_user['user_type']
                            ) ?>">

                                <?= htmlspecialchars(
                                    formatRole(
                                        $recent_user['user_type']
                                    )
                                ) ?>

                            </span>

                        </article>

                    <?php endwhile; ?>

                </div>

            <?php else: ?>

                <div class="admin-empty-state">

                    <span>👤</span>

                    <h3>No users found</h3>

                    <p>
                        Registered users will appear here.
                    </p>

                </div>

            <?php endif; ?>

        </div>

    </section>


</main>



<script>
const monthLabels = <?= json_encode($month_labels) ?>;
const monthlyBookingCommissions = <?= json_encode($monthly_booking_commissions) ?>;
const monthlyCabinRegistrations = <?= json_encode($monthly_cabin_registrations) ?>;
const monthlyAttractionRegistrations = <?= json_encode($monthly_attraction_registrations) ?>;

const revenueSourceLabels = <?= json_encode($revenue_source_labels) ?>;
const revenueSourceValues = <?= json_encode($revenue_source_values) ?>;

const monthlyCanvas = document.getElementById('adminMonthlyRevenueChart');

if (monthlyCanvas) {
    new Chart(monthlyCanvas, {
        type: 'bar',
        data: {
            labels: monthLabels,
            datasets: [
                {
                    label: 'Booking Commissions (₪)',
                    data: monthlyBookingCommissions
                },
                {
                    label: 'Cabin Owner Registrations (₪)',
                    data: monthlyCabinRegistrations
                },
                {
                    label: 'Attraction Owner Registrations (₪)',
                    data: monthlyAttractionRegistrations
                }
            ]
        },
        options: {
            responsive: true,
            interaction: {
                mode: 'index',
                intersect: false
            },
            scales: {
                x: {
                    stacked: true
                },
                y: {
                    stacked: true,
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Revenue (₪)'
                    }
                }
            }
        }
    });
}

const sourceCanvas = document.getElementById('adminRevenueSourcesChart');

if (sourceCanvas) {
    new Chart(sourceCanvas, {
        type: 'doughnut',
        data: {
            labels: revenueSourceLabels,
            datasets: [
                {
                    data: revenueSourceValues
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const value = Number(context.raw || 0);
                            const total = revenueSourceValues.reduce(
                                (sum, item) => sum + Number(item || 0),
                                0
                            );
                            const percentage = total > 0
                                ? ((value / total) * 100).toFixed(1)
                                : '0.0';

                            return `${context.label}: ₪${value.toLocaleString('he-IL', {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                            })} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}
</script>


</body>
</html>

<?php
$conn->close();
?>